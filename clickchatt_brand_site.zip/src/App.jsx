import React, { useState } from "react";

const categories = ["Cleaners","Handymen","Landscaping","Barbers","HVAC","Plumbers","Electricians","Moving","Pressure Washing","Auto Detail"];

export default function App(){
  const [q, setQ] = useState("");
  return (
    <main className="hero">
      <div className="card">
        <div className="brand">
          <div className="logo">CC</div>
          <div>
            <div style={{fontWeight:800,color:"#1e3a8a"}}>ClickChatt</div>
            <div style={{fontSize:12,color:"#6b7280"}}>Chattanooga’s Trusted Local Directory</div>
          </div>
        </div>

        <h1 className="h1">Hire local pros you can trust — fast.</h1>
        <p className="tag">Browse verified service providers across Chattanooga with real testimonials and our TrustLocal™ badge.</p>

        <div className="search">
          <input
            value={q}
            onChange={(e)=>setQ(e.target.value)}
            placeholder="Try 'Pressure washing in Hixson'"
            aria-label="Search services"
          />
          <button onClick={()=>alert(`Searching ClickChatt for: ${q || "all services"}`)}>Search</button>
        </div>

        <div className="ctas">
          <a className="primary" href="#" onClick={(e)=>{e.preventDefault(); alert("Provider onboarding coming soon");}}>List Your Business</a>
          <a href="#" onClick={(e)=>{e.preventDefault(); window.scrollTo({top:document.body.scrollHeight, behavior:"smooth"});}}>Browse Categories</a>
        </div>

        <div className="badge">✅ TrustLocal™ Verified — providers respond within 48h & have at least one testimonial.</div>

        <div className="grid">
          {categories.map(c => (
            <div className="tile" key={c}>
              <b>{c}</b>
              <span style={{color:"#6b7280"}}>Top-rated {c.toLowerCase()} in your area</span>
            </div>
          ))}
        </div>

        <div className="footer">
          © {new Date().getFullYear()} ClickChatt • <a href="#">Privacy</a> • <a href="#">Contact</a>
        </div>
      </div>
    </main>
  );
}