
# ClickChatt Brands (Vercel-ready)

A minimal Vite + React starter that **builds on Vercel**. Use this when your previous deploy failed with `Command "vite build" exited with 127`.

## Quick Deploy (GitHub → Vercel)
1. Create or open your GitHub repo.
2. Upload these files (or replace existing ones) to the root of the repo.
3. Commit & push.
4. In Vercel, hit **Redeploy**.

## Local Dev (optional)
```bash
npm install
npm run dev
```

## Production Build
```bash
npm run build
npm run preview
```

## Why this works
- Includes `vite` and `@vitejs/plugin-react` in **devDependencies**.
- Provides `"build": "vite build"` script.
- Uses standard Vite structure recognized by Vercel.
