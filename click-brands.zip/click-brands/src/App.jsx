
import React from 'react'

export default function App() {
  return (
    <div className="wrap">
      <header className="hero">
        <h1>ClickChatt</h1>
        <p className="tag">Hyper‑local directory & media for Chattanooga</p>
        <div className="cta-row">
          <a className="btn" href="#clickchatt">Explore ClickChatt</a>
          <a className="btn ghost" href="#click2chatt">Explore Click2Chatt</a>
        </div>
      </header>

      <section id="clickchatt" className="card">
        <h2>ClickChatt — Trusted Local Directory</h2>
        <ul>
          <li>Browse verified providers by neighborhood & category</li>
          <li>TrustLocal™ badges to highlight fast, responsive pros</li>
          <li>One‑tap contact and bookmark lists</li>
        </ul>
      </section>

      <section id="click2chatt" className="card">
        <h2>Click2Chatt — Deals, Events, & Quick Jobs</h2>
        <ul>
          <li>Flash deals and weekend events</li>
          <li>Micro‑gigs and last‑minute help board</li>
          <li>SMS-friendly posts you can manage on your phone</li>
        </ul>
      </section>

      <footer className="foot">
        <p>© {new Date().getFullYear()} ClickChatt Brands. All rights reserved.</p>
      </footer>
    </div>
  )
}
